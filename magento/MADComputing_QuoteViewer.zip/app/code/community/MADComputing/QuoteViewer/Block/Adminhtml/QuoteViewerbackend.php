<?php  

class MADComputing_QuoteViewer_Block_Adminhtml_QuoteViewerbackend extends Mage_Adminhtml_Block_Template {

}